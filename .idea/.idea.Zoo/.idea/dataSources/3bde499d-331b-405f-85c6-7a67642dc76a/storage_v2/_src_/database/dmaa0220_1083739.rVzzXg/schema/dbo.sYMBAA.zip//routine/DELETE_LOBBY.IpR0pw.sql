CREATE   PROCEDURE DELETE_LOBBY
    @LobbyCode NCHAR(4)
AS
    BEGIN TRANSACTION;
        UPDATE [User]
        SET LobbyCode = NULL
        WHERE Id IN (5, 6);
    
        UPDATE GameLobby
        SET GameId = NULL
        WHERE Code = @LobbyCode;
    
        UPDATE Game
        SET ActiveRoundId = NULL
        WHERE GameLobbyCode = @LobbyCode;
    
        DELETE FROM ChatMessage
        WHERE TurnId = (
            SELECT ActiveTurnId 
            FROM Round
            INNER JOIN Game G on G.Id = Round.GameId
            WHERE G.GameLobbyCode = @LobbyCode
        );
    
        UPDATE Round
        SET ActiveTurnId = NULL
        WHERE GameId = (SELECT Id FROM Game WHERE GameLobbyCode = @LobbyCode);
    
        DELETE FROM Turn
        WHERE RoundId IN (
            SELECT Id
            FROM Round
            WHERE GameId = (SELECT Id FROM Game WHERE GameLobbyCode = @LobbyCode)
        );
    
        DELETE FROM GameSetting
        WHERE GameLobbyCode = @LobbyCode;
    
        DELETE FROM Game
        WHERE GameLobbyCode = @LobbyCode;
    
        DELETE FROM GameLobby
        WHERE Code = @LobbyCode;
    COMMIT TRANSACTION;
;
go

