CREATE PROCEDURE SETUP_LOBBY
    @LobbyCode NCHAR(4)
AS
    BEGIN TRANSACTION;
        INSERT INTO Game(ActiveRoundId, GameLobbyCode)
        VALUES (NULL, @LobbyCode);
        DECLARE @GameId AS INT = SCOPE_IDENTITY();
        
        INSERT INTO Round(RoundNumber, GameId, ActiveTurnId)
        VALUES (1, @GameId, NULL);
        DECLARE @RoundId AS INT = SCOPE_IDENTITY();
        
        INSERT INTO Turn(RoundId, UserId, Word, StartedAt)
        VALUES (@RoundId, 5, 'Cake', GETUTCDATE());
        DECLARE @TurnId AS INT = SCOPE_IDENTITY();
        
        UPDATE Round
        SET ActiveTurnId = @TurnId
        WHERE Id = @RoundId;
        
        UPDATE Game
        SET ActiveRoundId = @RoundId
        WHERE GameLobbyCode = @LobbyCode;
        
        UPDATE GameLobby
        SET GameId = @GameId
        WHERE Code = @LobbyCode;
    COMMIT TRANSACTION;
;
go

